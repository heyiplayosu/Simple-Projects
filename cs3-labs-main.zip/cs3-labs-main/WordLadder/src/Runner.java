import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

public class Runner {
    public static void main(String[]args) {
      WordLadder wl = new WordLadder();
      wl.process();
    }
}
