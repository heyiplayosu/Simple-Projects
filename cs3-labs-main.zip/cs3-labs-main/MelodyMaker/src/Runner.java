import java.util.LinkedList;
import java.util.Queue;

public class Runner {
    public static void main (String[]args) {

    }
}
