Use the text files to test your hash map.

The Large Data Set contains 50k records of names, phone numbers, etc.

The Successful Search Records file contains only records that exist in the large data set (and vice versa for Unsuccessful Search Records).
